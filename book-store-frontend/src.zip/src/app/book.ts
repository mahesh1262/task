export class Book {
  id: number;
  title: string;
  year: string;
  price: number;
  language: string;
  catagory: string;
  }
